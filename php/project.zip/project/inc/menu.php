<div id="menu">
    <h4>Lecturer's Payment <br />Management System</h4>
    <ul>
        <li><a href=""><i class="fa fa-home"></i> Home</a></li>
        <li><a href="course.php"><i class="fa fa-book"></i> Course</a></li>
        <li><a href="batch.php"><i class="fa fa-layer-group"></i> Batch</a></li>
        <li><a href="subject.php"  ><i class="fa fa-book-open"></i> Subject</a></li>
        <li><a href="teacher.php"><i class="fa fa-chalkboard-teacher"></i> Teacher</a></li>
        <li><a href="lecture.php"><i class="fa fa-chalkboard"></i> Lecture</a></li>
        <li><a href="payment.php"><i class="fa fa-money-check-alt"></i> Payment</a></li>
        <li><a href="report.php"><i class="fa fa-chart-bar"></i> Reports</a></li>
        <li><a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>