<?php
if (isset($_REQUEST['success']) == true)
    echo "<div class='success'>{$_REQUEST['success']}</div>";
