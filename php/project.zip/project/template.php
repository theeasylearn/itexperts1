<?php 
    require_once('inc/header-part.php');
?>
</head>

<body>
    <?php require_once('inc/menu.php'); ?>
    <div class="heading">
        <div>
            <span>module heading</span>
            <span><a href="add_course.php">Link</a></span>
        </div>
    </div>
    <div class="container">
        
    </div>
</body>
<?php 
    require_once('inc/footer.php');
?>